<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# Estrela-guia

Estudantes de Cálculo entendem e resolvem seus problemas de Cálculo 1 e 2.

## Métrica

Resoluções passo a passo entregues a estudantes (respostas do tutor exibidas ou respostas do ENADE corrigidas) por semana
