# Refinamento visual
- [x] Adicionar apresentação educacional de cinco slides no guia, com navegação, teclado/toque, URL por slide e leitura mobile; testes e navegação verificados.
- [x] Adicionar Modo Código informativo nos quatro módulos com expressão, árvore de parsing, prévia das amostras reais 2D/3D, derivação e estado do renderizador; edição, alternância, celular e 163 testes verificados.
- [x] Remover Tutor, ENADE, Copiloto, chamadas e dependência de IA; tour de 10 passos e guia de 11 capítulos atualizados, seis abas verificadas, link antigo redirecionado e 160 testes aprovados.
- [x] Adicionar página no Como Usar explicando código, abas e funcionalidades; acesso pelo menu, busca, capítulos e leitura mobile verificados.
- [x] Exibir derivadas simbólicas e integrais indefinidas formatadas, com valores de x₀ independentes por função; preservar cálculos definidos e verificar casos do relatório (173 testes e conferência visual; primitivas não verificadas recebem aviso).
- [x] Corrigir domínio e intervalos de monotonia, derivabilidade, limites e integrais apontados no relatório; padronizar fórmulas principais e verificar casos pendentes e preservação dos parâmetros. Integrais impróprias gerais continuam exigindo análise de convergência separada, sem retornar números não verificados.
- [x] Tratar constantes na análise UV e nas regras de derivação sem enumerar raízes ou pontos críticos; verificar testes e interface.
- [x] Ajustar foco nativo, alvos de toque e layout móvel; verificar digitação, teclado científico e gestos 2D (teclado do sistema em aparelhos físicos ainda não verificado).
- [x] Separar explicitamente trechos descontínuos nos dois gráficos 2D e verificar cortes por altura visível e polos racionais.
- [x] Reduzir trabalho do zoom/pan 2D com orçamento de amostras e atualizações por quadro; verificar descontinuidades e desempenho.
- [x] Adicionar autocompletar nos campos das quatro abas; verificar clique, Tab/Enter, Esc e cursor.
- [x] Corrigir descontinuidades e amostragem dinâmica no zoom out dos dois gráficos 2D; verificar funções racionais e raízes contínuas.
- [x] Otimizar carregamento e troca de abas com pré-carregamento, renderização eficiente e preservação de estado; verificar navegação e recursos.
- [x] Atualizar os exemplos oficiais das quatro abas, manter um único exemplo 3D e verificar seleção e cálculos.
- [x] Adicionar zoom/pan compartilhado aos gráficos 2D, ticks adaptativos e cursor preciso; verificar mouse e touch.
- [x] Ampliar tour com atalhos, teclado científico e Aprenda; validar sintaxe e navegação.
- [x] Refinar identidade, navegação e controles compartilhados.
- [x] Harmonizar as seis abas e gráficos sem mudar os cálculos.
- [x] Verificar navegação, teclado matemático, telas estreitas e testes existentes.

# Manual avançado Aprenda
- [x] Expandir os conteúdos de Cálculo 1 e 2 com hipóteses, fórmulas e exemplos detalhados.
- [x] Organizar índice por curso e unidades, acordeões e destaque de teoremas.
- [x] Verificar fórmulas e navegação no manual em telas amplas e estreitas.

# Comparação de funções
- [x] Reformular a Tabela de Valores com as modalidades x→f(x) e f(x)→x por função, absorvendo o painel de Função Inversa, com dados independentes por função e limpeza individual/geral.
- [x] Adicionar gestão de até cinco funções em Funções e Derivadas.
- [x] Comparar curvas com Recharts, cores distintas e legenda interativa.
- [x] Verificar limite, exclusão, reinserção e gráficos nos dois módulos.

# Modo Quadro Negro
- [x] Adicionar alternância no cabeçalho e persistência local.
- [x] Aplicar tokens, escrita de giz, moldura e anotações aos gráficos.
- [x] Verificar alternância, recarregamento e interações em todas as abas.

# Lousa realista
- [x] Refinar madeira, superfície apagada e contornos de giz.
- [x] Acrescentar setas, guias amarelas e calha com apagador e gizes.
- [x] Verificar aparência e interações sem alterar o modo padrão.
- [x] Preserve each module state (inputs, points, 3D, mode) across tab navigation
