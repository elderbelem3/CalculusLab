/** Theme requests used by the local guided tour. */
export const EV_THEME = "calculuslab:set-theme";
export type ThemeEventDetail = { chalkboard?: boolean; blacklight?: boolean };