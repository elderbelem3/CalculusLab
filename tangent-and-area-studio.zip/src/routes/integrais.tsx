import { useModuleState } from "@/lib/module-state";
import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useRef } from "react";
import { parseFn, fmt } from "@/lib/calc";
import { MathExpression } from "@/components/MathExpression";
import { expressionLatex } from "@/lib/math-format";
import { Plot } from "@/components/Plot";
import { IntegralUvOverlay } from "@/components/UvOverlays";
import { UvStepsPanel } from "@/components/UvStepsPanel";
import { definiteIntegral, indefiniteIntegral } from "@/lib/uv-steps";
import { Smart3DView } from "@/components/Smart3DView";
import { solidSteps } from "@/lib/smart3d";
import { integralExamples } from "@/lib/study-examples";
import { Button } from "@/components/ui/button";
import { PageHeader, Panel, Field, ErrorBox, Chip, MathToolbar, Stat, num } from "@/components/Lab";
import { CodeInspector } from "@/components/CodeMode";

export const Route = createFileRoute("/integrais")({
  head: () => ({
    meta: [
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { title: "Integrais · CalculusLab" },
      { name: "description", content: "Veja integrais indefinidas em notação matemática e calcule integrais definidas com área sob a curva." },
      { property: "og:title", content: "Integrais · CalculusLab" },
      { property: "og:description", content: "Primitivas com constante de integração e integrais definidas como área acumulada." },
    ],
  }),
  component: Integrais,
});

function Integrais() {
  const [expr, setExpr] = useModuleState("integrais.expr", "x^2");
  const [aS, setA] = useModuleState("integrais.aS", "0");
  const [bS, setB] = useModuleState("integrais.bS", "2");
  const [mode, setMode] = useModuleState<"area" | "solido">("integrais.mode", "area");
  const inputRef = useRef<HTMLInputElement>(null);
  const { fn, error } = useMemo(() => parseFn(expr), [expr]);
  const primitive = useMemo(() => indefiniteIntegral(expr), [expr]);
  const a = num(aS), b = num(bS);
  const valid = fn && a !== null && b !== null;
  const result = useMemo(() => valid ? definiteIntegral(expr, a, b) : null, [valid, expr, a, b]);
  const value = result?.value ?? NaN;
  const bad = valid && !Number.isFinite(value);
  const lo = valid ? Math.min(a, b) : 0, hi = valid ? Math.max(a, b) : 1;
  const solid = valid && mode === "solido" ? solidSteps(expr, a, b) : null;
  const pad = Math.max(1, (hi - lo) * 0.4);

  return (
    <>
      <PageHeader tag="Módulo 04" title="Integrais" desc="A integral definida de a até b acumula a área (com sinal) entre a curva e o eixo x." />
      <div className="grid gap-6 lg:grid-cols-[360px_minmax(0,1fr)]">
        <div className="space-y-5">
          <Panel>
            <div className="space-y-5">
              <MathToolbar inputRef={inputRef} value={expr} onChange={setExpr} />
              <Field ref={inputRef} label="f(x) =" value={expr} onChange={setExpr} />
              <div className="flex flex-wrap gap-2">
                {integralExamples.map((e) => <Chip key={e.label} onClick={() => { setExpr(e.expression); setA(e.a); setB(e.b); }}>{e.label}</Chip>)}
              </div>
              <div className="grid grid-cols-2 gap-2">
                <Field label="Limite inferior a" value={aS} onChange={setA} />
                <Field label="Limite superior b" value={bS} onChange={setB} />
              </div>
              <div>
                <span className="mb-1 block text-sm font-medium text-muted-foreground">Interpretação</span>
                <div className="grid grid-cols-2 gap-1 rounded-lg bg-secondary p-1">
                  {([["area", "Área"], ["solido", "Sólido de revolução"]] as const).map(([v, l]) => <Button key={v} variant="ghost" size="sm" aria-pressed={mode === v} onClick={() => setMode(v)} className={`rounded-md text-sm ${mode === v ? "bg-card text-primary shadow-soft" : "text-muted-foreground"}`}>{l}</Button>)}
                </div>
              </div>
              {error && <ErrorBox msg={error} />}
              {(a === null || b === null) && <ErrorBox msg="Informe números válidos para a e b." />}
              {bad && <ErrorBox msg={result?.error ?? "Não foi possível estabelecer uma integral finita no intervalo."} />}
            </div>
          </Panel>
          {fn && <Panel title="Integral indefinida">
            <div className="space-y-4">
              <div><p className="text-xs font-medium text-muted-foreground">Função original</p><MathExpression expression={expr} prefix="f(x) = " /></div>
              <div><p className="text-xs font-medium text-muted-foreground">Integral indefinida</p>{primitive !== null ? <MathExpression expression={primitive} prefix="F(x) = " suffix=" + C" /> : <p className="text-sm text-muted-foreground">Não foi possível obter uma primitiva simbólica verificada pelo método disponível. A integração definida continua disponível quando o intervalo é válido.</p>}</div>
              {primitive !== null && <p className="text-xs text-muted-foreground">C é a constante de integração. A primitiva vale em cada intervalo do domínio da função.</p>}
            </div>
          </Panel>}
          {valid && !bad && (mode === "solido" && solid ? <Stat label={`V = π ∫ de ${fmt(a)} a ${fmt(b)} f(x)² dx`} value={fmt(solid.volume, 6)} /> : <Panel title="Integral definida"><MathExpression expression={fmt(value, 6)} prefix={`\\int_{${a}}^{${b}} \\left(${expressionLatex(expr)}\\right)\\,dx ${result?.method === "Simpson" ? "\\approx" : "="} `} /></Panel>)}
        </div>
        <div className="min-w-0 space-y-6">
          <Panel title={mode === "solido" ? "Sólido de revolução (3D)" : "Área sob a curva"}>
            {valid && mode === "solido" && !bad ? <><Smart3DView scene={{ kind: "solid", expression: expr, a, b }} /><UvStepsPanel title="Volume pelo Método dos Discos" steps={solid?.steps ?? null} /></> : valid ? <Plot fn={fn} expression={expr} xMin={lo - pad} xMax={hi + pad} {...(bad ? {} : { shade: [a, b] as [number, number], overlay: (h: import("@/components/Plot").PlotHelpers) => <IntegralUvOverlay h={h} a={a} b={b} value={value} /> })} /> : <p className="text-muted-foreground">Corrija os campos para ver o gráfico.</p>}
            {valid && !bad && mode === "area" && <UvStepsPanel title="Antiderivada e Teorema Fundamental" steps={result?.steps ?? null} />}
          </Panel>
          <Panel title="Integral como área acumulada">
            <div className="space-y-2 text-sm leading-relaxed text-muted-foreground">
              <p>Divida [a, b] em n retângulos de largura Δx. A soma de Riemann <span className="font-mono text-foreground">Σ f(xᵢ)·Δx</span> aproxima a área sob a curva.</p>
              <p>Quando n → ∞ (Δx → 0), a soma converge para a <strong className="text-foreground">integral definida</strong>:</p>
              <p className="rounded-lg bg-secondary p-3 text-center font-mono text-foreground">∫ₐᵇ f(x) dx = lim n→∞ Σ f(xᵢ)·Δx</p>
              <p>Regiões abaixo do eixo x contribuem com área <strong className="text-foreground">negativa</strong>. Pelo Teorema Fundamental do Cálculo, em um intervalo de continuidade, se F' = f, então a integral vale F(b) − F(a).</p>
              {result?.method && !bad && <p>Método utilizado: {result.method === "primitiva" ? "primitiva e Teorema Fundamental do Cálculo — F(b) − F(a)." : "aproximação numérica pela regra de Simpson."}</p>}
            </div>
          </Panel>
        </div>
      </div>
      <CodeInspector expressions={[expr]} renderer={valid && mode === "solido" && !bad ? "Three.js 3D" : "SVG 2D"} blocked={!valid} />
    </>
  );
}
